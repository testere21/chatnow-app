﻿export { default } from './splash';
