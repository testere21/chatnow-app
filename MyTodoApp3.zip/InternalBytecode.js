// InternalBytecode.js - Metro bundler için placeholder dosya
// Bu dosya Metro bundler tarafından aranıyor ama bulunamıyor
// Bu yüzden hata veriyor

module.exports = {};
